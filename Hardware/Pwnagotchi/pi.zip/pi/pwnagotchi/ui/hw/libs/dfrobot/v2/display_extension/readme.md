wqydkzh.ttf = 文泉驿等宽正黑.ttf GPL2 license </br>
zkklt.ttf = 站酷快乐体.ttf Chinese open source fonts file, use with freetype_helper.py