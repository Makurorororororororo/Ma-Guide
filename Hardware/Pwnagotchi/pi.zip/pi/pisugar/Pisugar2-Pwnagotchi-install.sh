#!/bin/bash

echo  "\033[1;34mOpen I2C Interface \033[0m"
sudo raspi-config nonint do_i2c 0

echo  "\033[1;34mInstall packages\033[0m"
sudo dpkg -i /home/pi/pisugar/pisugar-server_1.4.4_armhf.deb /home/pi/pisugar/pisugar-poweroff_1.4.4_armhf.deb 


sudo mkdir -p /usr/local/share/pwnagotchi/installed-plugins/
sudo ln -s /home/pi/pisugar/pisugar2py/ /usr/local/lib/python3.7/dist-packages/pisugar2
sudo ln -s /home/pi/pisugar/pwnagotchi-pisugar2-plugin/pisugar2.py /usr/local/share/pwnagotchi/installed-plugins/pisugar2.py

sudo cp -f /home/pi/pisugar/config.toml /etc/pwnagotchi/config.toml

echo  "If you have any question,please feel free to contact us."
echo  "\033[1;34mThe PiSugar Team https://www.pisugar.com\033[0m"
sudo shutdown now
