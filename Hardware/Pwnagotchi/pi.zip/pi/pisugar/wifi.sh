#/bin/bash

a=`ifconfig | grep  "mon"`
echo $a
b="mon"
result=$(echo $a | grep "${b}")
if [ "$result" != "" ] ; then
    echo " find mon0"
sudo kill -STOP $(pgrep pwnagotchi)
sudo kill -STOP $(pgrep bettercap)

		#替换文件，关闭USB0作为默认网卡的设置
		sudo cp /home/pi/pisugar/usb0-cfg-1 /etc/network/interfaces.d/usb0-cfg 
		sleep 3
		#关闭监听的虚拟网卡
		sudo ifconfig mon0 down
		#删除默认网关地址
		sudo ip route del default
		sleep 3
		#启动wpa服务，开始联网
		sudo wpa_supplicant -B -i wlan0 -c /etc/wpa_supplicant/wpa_supplicant.conf
		sleep 3
		#启动DHCP服务获取IP
		sudo dhclient wlan0
		sleep 3

else
    echo " not find mon0"
		#关闭wpa进程
		sudo killall wpa_supplicant
		sudo killall dhclient
		#关闭wlan0网卡
		sudo ifconfig wlan0 down
		sleep 3
		#启动监听网卡
		sudo ifconfig mon0 up
		#替换文件，恢复USB0作为默认网卡的设置
		sudo cp /home/pi/pisugar/usb0-cfg-2 /etc/network/interfaces.d/usb0-cfg 
sudo kill -CONT $(pgrep pwnagotchi)
sudo kill -CONT $(pgrep bettercap)

fi
